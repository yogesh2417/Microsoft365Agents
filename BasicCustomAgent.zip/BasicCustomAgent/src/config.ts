const config = {
  openAIKey: process.env.OPENAI_API_KEY,
  openAIModelName: "llama3.2",
};

export default config;
